/*

Copyright (C) 2021 MagicLogics LLC.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, version 3.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.

*/

package com.magiclogics.magictube;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class BookmarksActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookmarks);

        ActionBar bar = getSupportActionBar();
        bar.setDisplayHomeAsUpEnabled(true);

        final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        String bookmarksJSONString2 = prefs.getString("video_bookmarks", "");
        if (!prefs.getString("video_bookmarks", "").equals("")) {
            Type type = new TypeToken<ArrayList<VideoBookmark>>() {}.getType();
            final ArrayList<VideoBookmark> bookmarks = new Gson().fromJson(bookmarksJSONString2, type);
            ArrayAdapter<VideoBookmark> bookmarkArrayAdapter = new ArrayAdapter<VideoBookmark>(this, R.layout.bookmark_adapter, bookmarks) {
                @Override
                public View getView(final int position, View convertView, ViewGroup parent) {
                    if (convertView == null) {
                        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                        convertView = inflater.inflate(R.layout.bookmark_adapter, parent, false);
                    }

                    TextView name = convertView.findViewById(R.id.video_name_textview);
                    name.setText(bookmarks.get(position).videoName);

                    TextView id = convertView.findViewById(R.id.video_id_textview);
                    id.setText(bookmarks.get(position).videoId);

                    Button remove = convertView.findViewById(R.id.bookmark_remove_button);
                    remove.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String bookmarksJSONString3 = prefs.getString("video_bookmarks", "");
                            Type type = new TypeToken<ArrayList<VideoBookmark>>() {
                            }.getType();
                            ArrayList<VideoBookmark> bookmarks = new Gson().fromJson(bookmarksJSONString3, type);
                            bookmarks.remove(bookmarks.get(position));

                            String bookmarksJSONString4 = new Gson().toJson(bookmarks);
                            prefs.edit().putString("video_bookmarks", bookmarksJSONString4).commit();

                            Intent intent = getIntent();
                            finish();
                            startActivity(intent);
                        }
                    });

                    return convertView;
                }
            };

            ListView view = findViewById(R.id.bookmarks_list);
            view.setAdapter(bookmarkArrayAdapter);
            view.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    WatchActivity.videoId = bookmarks.get(position).videoId;
                    startActivity(new Intent(BookmarksActivity.this, WatchActivity.class));
                }
            });
        }
    }
}
