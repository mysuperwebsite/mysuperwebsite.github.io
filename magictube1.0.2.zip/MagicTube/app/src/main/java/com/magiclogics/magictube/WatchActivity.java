/*

Copyright (C) 2021 MagicLogics LLC.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, version 3.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.

*/

package com.magiclogics.magictube;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WatchActivity extends AppCompatActivity {

    static String videoId;
    WebView view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_watch);

        view = findViewById(R.id.webView2);
        view.getSettings().setJavaScriptEnabled(true);
        view.setWebViewClient(new WebViewClient());
        view.loadUrl("https://www.youtube-nocookie.com/embed/" + videoId);
        view.setWebViewClient(new WebViewClient() {

            @Override
            public void onLoadResource(WebView view, String url) {
                if (url.contains("https://www.youtube.com/watch?v=") || url.contains("https://m.youtube.com/watch?v=")) {
                    view.stopLoading();
                    String[] args = url.split("=v");
                    int index = url.indexOf("=");
                    String videoId = getYouTubeId(url); //https://stackoverflow.com/a/57131676
                    videoId = videoId.replace("&pbj=1", "");
                    WatchActivity.videoId = videoId;
                    view.loadUrl("https://www.youtube-noccokie.com/embed/" + videoId);
                }
            }
        });
        if (Build.VERSION.SDK_INT >= 21) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(view, true);
        } else {
            CookieManager.getInstance().setAcceptCookie(true);
        }
    }

    /**
     From Stack Overflow
     <br>
     From: <a href="https://stackoverflow.com/a/57131676">https://stackoverflow.com/a/57131676"</a><br>
     User: <a href="https://stackoverflow.com/users/7548514/kyo-huu">Kyo Huu</a>
     Modifications: None
     License link: https://creativecommons.org/licenses/by-sa/4.0/legalcode
     */
    private String getYouTubeId(String youTubeUrl) {
        String pattern = "https?://(?:[0-9A-Z-]+\\.)?(?:youtu\\.be/|youtube\\.com\\S*[^\\w\\-\\s])([\\w\\-]{11})(?=[^\\w\\-]|$)(?![?=&+%\\w]*(?:['\"][^<>]*>|</a>))[?=&+%\\w]*";

        Pattern compiledPattern = Pattern.compile(pattern,
                Pattern.CASE_INSENSITIVE);
        Matcher matcher = compiledPattern.matcher(youTubeUrl);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return null;
    }

    @Override
    public void onBackPressed() {
        if (view.canGoBack()) {
            view.goBack();
        } else {
            finish();
        }
    }
}
