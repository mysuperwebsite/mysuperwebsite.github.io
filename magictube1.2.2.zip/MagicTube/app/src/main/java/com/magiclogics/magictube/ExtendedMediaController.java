/*

Copyright (C) 2021 MagicLogics LLC.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, version 3.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.

*/

package com.magiclogics.magictube;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.view.KeyEvent;
import android.view.View;
import android.widget.MediaController;

public class ExtendedMediaController extends MediaController {
    private Activity mParentActivity;

    public ExtendedMediaController(Context context, Activity parentActivity) {
        super(context);
        mParentActivity = parentActivity;

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            OnUnhandledKeyEventListener eventListener = new OnUnhandledKeyEventListener() {
                @Override
                public boolean onUnhandledKeyEvent(View v, KeyEvent event) {
                    boolean fHandled = false;

                    if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
                        if (event.getAction() == KeyEvent.ACTION_DOWN) {
                            fHandled =  true;
                        } else if (event.getAction() == KeyEvent.ACTION_UP) {
                            if(mParentActivity != null) {
                                mParentActivity.onBackPressed();
                                fHandled = true;
                            }
                        }
                    }
                    return(fHandled);
                }
            };
            addOnUnhandledKeyEventListener(eventListener);
        }

    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        boolean fHandled = false;
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                fHandled =  true;
            } else if (event.getAction() == KeyEvent.ACTION_UP) {
                mParentActivity.onBackPressed();
                fHandled = true;
            }
        }
        if(!fHandled) {
            fHandled = super.dispatchKeyEvent(event);
        }
        return(fHandled);
    }


}