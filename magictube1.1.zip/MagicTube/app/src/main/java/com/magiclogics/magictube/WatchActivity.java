/*

Copyright (C) 2021 MagicLogics LLC.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, version 3.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.

*/

package com.magiclogics.magictube;

import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.util.SparseArray;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.apache.commons.io.IOUtils;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.net.URL;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import at.huber.youtubeExtractor.VideoMeta;
import at.huber.youtubeExtractor.YouTubeExtractor;
import at.huber.youtubeExtractor.YtFile;

public class WatchActivity extends AppCompatActivity {

    static String videoId;
    WebView view2;
    static String youtubeTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_watch);

        view2 = findViewById(R.id.webView2);
        view2.getSettings().setJavaScriptEnabled(true);
        view2.setWebViewClient(new WebViewClient());
        view2.loadUrl("https://www.youtube-nocookie.com/embed/" + videoId);
        view2.setWebViewClient(new WebViewClient() {

            @Override
            public void onLoadResource(WebView view, String url) {
                if (url.contains("https://www.youtube.com/watch?v=") || url.contains("https://m.youtube.com/watch?v=")) {
                    view.stopLoading();
                    String[] args = url.split("=v");
                    int index = url.indexOf("=");
                    String videoId = getYouTubeId(url); //https://stackoverflow.com/a/57131676
                    videoId = videoId.replace("&pbj=1", "");
                    WatchActivity.videoId = videoId;
                    view.loadUrl("https://www.youtube-nocookie.com/embed/" + videoId);
                }
            }
        });
        if (Build.VERSION.SDK_INT >= 21) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(view2, true);
        } else {
            CookieManager.getInstance().setAcceptCookie(true);
        }
    }

    /**
     From Stack Overflow
     <br>
     From: <a href="https://stackoverflow.com/a/57131676">https://stackoverflow.com/a/57131676"</a><br>
     User: <a href="https://stackoverflow.com/users/7548514/kyo-huu">Kyo Huu</a>
     Modifications: None
     License link: https://creativecommons.org/licenses/by-sa/4.0/legalcode
     */
    private String getYouTubeId(String youTubeUrl) {
        String pattern = "https?://(?:[0-9A-Z-]+\\.)?(?:youtu\\.be/|youtube\\.com\\S*[^\\w\\-\\s])([\\w\\-]{11})(?=[^\\w\\-]|$)(?![?=&+%\\w]*(?:['\"][^<>]*>|</a>))[?=&+%\\w]*";

        Pattern compiledPattern = Pattern.compile(pattern,
                Pattern.CASE_INSENSITIVE);
        Matcher matcher = compiledPattern.matcher(youTubeUrl);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return null;
    }

    @Override
    public void onBackPressed() {
        if (view2.canGoBack()) {
            view2.goBack();
        } else {
            finish();
        }
    }

    public static String getTitleQuietly(String youtubeUrl) {
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

        StrictMode.setThreadPolicy(policy);
        try {
            if (youtubeUrl != null) {
                URL embededURL = new URL("https://www.youtube.com/oembed?url=" +
                        youtubeUrl + "&format=json"
                );

                return new JSONObject(IOUtils.toString(embededURL)).getString("title");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public void onMoreClick(View view) {
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(WatchActivity.this, android.R.layout.simple_list_item_1);
        adapter.add(WatchActivity.this.getString(R.string.add_to_bookmarks));
        adapter.add(WatchActivity.this.getString(R.string.download_video));
        AlertDialog.Builder dialog = new AlertDialog.Builder(WatchActivity.this);
        dialog.setAdapter(adapter, new DialogInterface.OnClickListener() {
            @SuppressLint("StaticFieldLeak")
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == 0) {
                    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(WatchActivity.this);
                    VideoBookmark bookmark = new VideoBookmark();
                    bookmark.videoId = getYouTubeId(view2.getUrl().replace("https://www.youtube-nocookie.com/embed/", "https://www.youtube.com/watch?v="));
                    bookmark.videoName = getTitleQuietly("https://www.youtube.com/watch?v=" + getYouTubeId(view2.getUrl().replace("https://www.youtube-nocookie.com/embed/", "https://www.youtube.com/watch?v=")));

                    if (prefs.getString("video_bookmarks", "").equals("")) {
                        ArrayList<VideoBookmark> bookmarks = new ArrayList<VideoBookmark>();
                        bookmarks.add(bookmark);

                        String bookmarksJSONString = new Gson().toJson(bookmarks);
                        prefs.edit().putString("video_bookmarks", bookmarksJSONString).commit();
                    } else {
                        String bookmarksJSONString2 = prefs.getString("video_bookmarks", "");
                        Type type = new TypeToken<ArrayList<VideoBookmark>>() {
                        }.getType();
                        ArrayList<VideoBookmark> bookmarks = new Gson().fromJson(bookmarksJSONString2, type);
                        bookmarks.add(bookmark);

                        String bookmarksJSONString = new Gson().toJson(bookmarks);
                        prefs.edit().putString("video_bookmarks", bookmarksJSONString).commit();
                    }
                } else if (which == 1) {
                    String youtubeLink = "https://www.youtube.com/watch?v=" + getYouTubeId(view2.getUrl().replace("https://www.youtube-nocookie.com/embed/", "https://www.youtube.com/watch?v="));

                    new YouTubeExtractor(WatchActivity.this) {
                        @Override
                        protected void onExtractionComplete(SparseArray<YtFile> ytFiles, VideoMeta videoMeta) {
                            if (ytFiles != null) {
                                int itag = 22;
                                String downloadUrl = ytFiles.get(itag).getUrl();

                                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(downloadUrl));
                                request.setDescription(getTitleQuietly("https://www.youtube.com/watch?v=" + getYouTubeId(view2.getUrl().replace("https://www.youtube-nocookie.com/embed/", "https://www.youtube.com/watch?v="))));
                                request.setTitle(WatchActivity.this.getString(R.string.downloading_video));
                                request.allowScanningByMediaScanner();
                                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                                request.setDestinationInExternalFilesDir(WatchActivity.this, null, getTitleQuietly("https://www.youtube.com/watch?v=" + getYouTubeId(view2.getUrl().replace("https://www.youtube-nocookie.com/embed/", "https://www.youtube.com/watch?v="))).replace(":", "") + ".mp4");

                                DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                                manager.enqueue(request);

                                SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(WatchActivity.this);
                                DownloadedVideo video = new DownloadedVideo();
                                video.videoName = getTitleQuietly("https://www.youtube.com/watch?v=" + getYouTubeId(view2.getUrl().replace("https://www.youtube-nocookie.com/embed/", "https://www.youtube.com/watch?v=")));
                                video.videoRealName = getTitleQuietly("https://www.youtube.com/watch?v=" + getYouTubeId(view2.getUrl().replace("https://www.youtube-nocookie.com/embed/", "https://www.youtube.com/watch?v="))).replace(":", "") + ".mp4";

                                if (prefs.getString("downloaded_videos", "").equals("")) {
                                    ArrayList<DownloadedVideo> bookmarks = new ArrayList<DownloadedVideo>();
                                    bookmarks.add(video);

                                    String bookmarksJSONString = new Gson().toJson(bookmarks);
                                    prefs.edit().putString("downloaded_videos", bookmarksJSONString).commit();
                                } else {
                                    String bookmarksJSONString2 = prefs.getString("downloaded_videos", "");
                                    Type type = new TypeToken<ArrayList<DownloadedVideo>>() {
                                    }.getType();
                                    ArrayList<DownloadedVideo> bookmarks = new Gson().fromJson(bookmarksJSONString2, type);
                                    bookmarks.add(video);

                                    String bookmarksJSONString = new Gson().toJson(bookmarks);
                                    prefs.edit().putString("downloaded_videos", bookmarksJSONString).commit();
                                }
                            }
                        }
                    }.extract(youtubeLink, true, true);
                }
                dialog.dismiss();
            }
        });
        dialog.show();
    }
}
