/*

Copyright (C) 2021 MagicLogics LLC.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.

*/

package com.magiclogics.magicdevicefinder;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

@SuppressWarnings("Convert2Lambda")
public class LocationService extends Service {
    FirebaseAuth auth;
    FirebaseUser currentUser;
    boolean isServerAccount = false;

    @Override
    public void onCreate() {
        super.onCreate();
        auth = FirebaseAuth.getInstance();
        currentUser = auth.getCurrentUser();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference root = database.getReference();

        if (currentUser != null) {
            Timer timer = new Timer();
            TimerTask task = new TimerTask() {
                @Override
                public void run() {
                    root.addChildEventListener(new ChildEventListener() {
                        @Override
                        public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                            for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                                System.out.println(snapshot1.getValue());
                                Type type = new TypeToken<AccountDetails>() {}.getType();
                                AccountDetails details = new Gson().fromJson(snapshot1.getValue().toString(), type);
                                String email;
                                String email_watcher;
                                try {
                                    Encryption encryption = Encryption.getDefault(auth.getCurrentUser().getEmail(), "Salt", new byte[16]);
                                    System.out.println("Encrypted: " + details.email2);
                                    email = encryption.decrypt(details.email2);
                                    email_watcher = details.watcherEmail;
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    continue;
                                }
                                if (auth.getCurrentUser().getEmail().equals(email)) {
                                    if (email_watcher.equals("")) {
                                        isServerAccount = true;
                                    } else {
                                        isServerAccount = false;
                                    }
                                }
                            }
                        }

                        @Override
                        public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                        }

                        @Override
                        public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                        }

                        @Override
                        public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                    String key = root.push().getKey();

                    Timer timer2 = new Timer();
                    TimerTask timerTask2 = new TimerTask() {
                        @SuppressLint("MissingPermission")
                        @Override
                        public void run() {
                            if (isServerAccount) {
                                // There is no way to get all children by default
                                // but there is a workaround:
                                // 1. Add a child event listener that watches for child event changes.
                                // 2. Add a child.
                                // 3. The listener gets called and we can get all of the entries.
                                LocationManager locationManager = (LocationManager)
                                        getSystemService(Context.LOCATION_SERVICE);
                                LocationListener listener = new LocationListener() {
                                    @Override
                                    public void onLocationChanged(Location location) {
                                        root.addChildEventListener(new ChildEventListener() {

                                            @Override
                                            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                                                for (DataSnapshot child : snapshot.getChildren()) {

                                                }

                                                String cityName = null;
                                                Geocoder gcd = new Geocoder(LocationService.this, Locale.getDefault());
                                                List<Address> addresses;
                                                try {
                                                    addresses = gcd.getFromLocation(location.getLatitude(),
                                                            location.getLongitude(), 1);
                                                    if (addresses.size() > 0) {
                                                        System.out.println(addresses.get(0).getLocality());
                                                        cityName = addresses.get(0).getLocality();
                                                    }
                                                } catch (IOException e) {
                                                    e.printStackTrace();
                                                }


                                                // Save new location to account details
                                                for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                                                    Type type = new TypeToken<AccountDetails>() {}.getType();
                                                    AccountDetails details = new Gson().fromJson(snapshot1.getValue().toString(), type);

                                                    System.out.println(auth.getCurrentUser().getEmail() + "=" + auth.getCurrentUser().getEmail().getBytes().length);

                                                    Encryption encryption = Encryption.getDefault(auth.getCurrentUser().getEmail(), "Salt", new byte[16]);
                                                    try {
                                                        encryption.decrypt(details.email2);
                                                    } catch (Exception e) {
                                                        continue;
                                                    }

                                                    details.locationName = encryption.encryptOrNull(cityName);
                                                    details.timestamp = Calendar.getInstance().getTime().getTime();
                                                    details.latitude = encryption.encryptOrNull(String.valueOf(location.getLatitude()));
                                                    details.longitude = encryption.encryptOrNull(String.valueOf(location.getLongitude()));

                                                    String json = new Gson().toJson(details);
                                                    System.out.println(snapshot1.getKey());
                                                    DatabaseReference ref = snapshot1.getRef();
                                                    ref.setValue(json);
                                                }
                                            }

                                            @Override
                                            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                                            }

                                            @Override
                                            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                                            }

                                            @Override
                                            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError error) {

                                            }
                                        });
                                        String key = root.push().getKey();
                                    }

                                    @Override
                                    public void onStatusChanged(String provider, int status, Bundle extras) {

                                    }

                                    @Override
                                    public void onProviderEnabled(String provider) {

                                    }

                                    @Override
                                    public void onProviderDisabled(String provider) {

                                    }
                                };
                                Looper.prepare();
                                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 10, listener);
                            }
                        }
                    };
                    timer2.schedule(timerTask2, 2000);
                }
            };
            timer.schedule(task, 15 * 1000, 15 * 1000);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
