package com.magiclogics.magicdevicefinder;

public class AccountDetails {
    String email2;
    String locationName;
    String watcherEmail;
    long timestamp;
    String longitude;
    String latitude;
}
