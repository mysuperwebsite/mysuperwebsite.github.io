/*

Copyright (C) 2021 MagicLogics LLC.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, version 3.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.

*/

package com.magiclogics.magictube;

import android.content.Intent;
import android.net.Uri;

import androidx.appcompat.app.AppCompatActivity;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DeepLinkActivity extends AppCompatActivity {
    @Override
    protected void onResume() {
        super.onResume();

        Intent in = getIntent();
        Uri data = in.getData();

        String videoId = getYouTubeId(data.toString()); //https://stackoverflow.com/a/57131676
        videoId = videoId.replace("&pbj=1", "");
        WatchActivity.videoId = videoId;
        startActivity(new Intent(DeepLinkActivity.this, WatchActivity.class));
    }

    /**
     From Stack Overflow
     <br>
     From: <a href="https://stackoverflow.com/a/57131676">https://stackoverflow.com/a/57131676"</a><br>
     User: <a href="https://stackoverflow.com/users/7548514/kyo-huu">Kyo Huu</a>
     Modifications: None
     License link: https://creativecommons.org/licenses/by-sa/4.0/legalcode
     */
    private String getYouTubeId(String youTubeUrl) {
        String pattern = "https?://(?:[0-9A-Z-]+\\.)?(?:youtu\\.be/|youtube\\.com\\S*[^\\w\\-\\s])([\\w\\-]{11})(?=[^\\w\\-]|$)(?![?=&+%\\w]*(?:['\"][^<>]*>|</a>))[?=&+%\\w]*";

        Pattern compiledPattern = Pattern.compile(pattern,
                Pattern.CASE_INSENSITIVE);
        Matcher matcher = compiledPattern.matcher(youTubeUrl);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return null;
    }
}
