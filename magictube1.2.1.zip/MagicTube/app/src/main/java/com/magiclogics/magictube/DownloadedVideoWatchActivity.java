/*

Copyright (C) 2021 MagicLogics LLC.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, version 3.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.

*/

package com.magiclogics.magictube;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.WindowManager;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

public class DownloadedVideoWatchActivity extends AppCompatActivity {
    static String videoName;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_downloaded_video_watch);

        final MyVideoView view = findViewById(R.id.videoView1);
        //Uri uri = Uri.parse("file://" + );
        view.setVideoURI(Uri.fromFile(new File(getExternalFilesDir(null) + "/" + videoName)));
        view.setMediaController(new ExtendedMediaController(this, this));
        view.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mp, int what, int extra) {
                // I've got many false positive video playing errors
                // video playing works perfectly with it
                return true;
            }
        });
        view.setPlayPauseListener(new MyVideoView.PlayPauseListener() {
            @Override
            public void onPlay() {
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }

            @Override
            public void onPause() {
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }
        });
        /*view.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                float videoRatio = mp.getVideoWidth() / (float) mp.getVideoHeight();
                float screenRatio = view.getWidth() / (float)
                        view.getHeight();
                float scaleX = videoRatio / screenRatio;
                ConstraintLayout layout = findViewById(R.id.downloaded_video_watch_layout);
                ConstraintSet constraintSet = new ConstraintSet();
                constraintSet.clone(constraintLayout);
                constraintSet.connect(R.id.videoView1 ,ConstraintSet.RIGHT,R,0);
                constraintSet.connect(R.id.imageView,ConstraintSet.TOP,R.id.check_answer2,ConstraintSet., 0);
                constraintSet.applyTo(constraintLayout);
                if (scaleX >= 1f) {
                    view.setScaleX(scaleX);
                } else {
                    view.setScaleY(1f / scaleX);
                }
            }
        });*/

        view.start();
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
