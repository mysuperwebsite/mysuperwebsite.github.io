/*

Copyright (C) 2021 MagicLogics LLC.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.

*/

package com.magiclogics.softwareupdate;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<AppDetail> apps;
    int upToDateApps = 0;
    int MAGICTUBE_REQUEST_CODE = 1000;
    int SOFTWAREUPDATE_REQUEST_CODE = 2000;
    int UNKNOWN_SOURCE_REQUEST_CODE = 3000;
    boolean receiverRegistered = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (!UpdaterService.onBoot) {
            UpdaterService.context = getApplicationContext();
            startService(new Intent(this, UpdaterService.class));
        } else if (!UpdaterService.isRunning) {
            UpdaterService.context = getApplicationContext();
            startService(new Intent(this, UpdaterService.class));
        }
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        @SuppressLint("StaticFieldLeak")
        AsyncTask<Void, Void, Void> task = new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                checkForUpdates();
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
            }
        };
        task.execute();
    }

    public void checkForUpdates() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                TextView view = findViewById(R.id.apps_item_label);
                view.setText(getString(R.string.updates_checking_title));
                TextView view2 = findViewById(R.id.apps_item_name);
                view2.setText(getString(R.string.updates_checking_desc));
            }
        });
        final FirebaseDatabase database = FirebaseDatabase.getInstance("https://magiclogicssoftwareupdat-b9f8e-default-rtdb.firebaseio.com/");

        apps = new ArrayList<>();

        final PackageManager pm = getPackageManager();
        List<PackageInfo> list = pm.getInstalledPackages(0);
        for (final PackageInfo info : list) {
            if (info.packageName.equals("com.magiclogics.magictube")) {
                final DatabaseReference reference = database.getReference("magicTubeVersionCode");
                reference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String versionCodeAndNumber = String.valueOf(dataSnapshot.getValue());
                        String[] versionCodeAndNumber2 = versionCodeAndNumber.split(":");
                        long versionCode = Long.parseLong(versionCodeAndNumber2[0]);
                        String new_version_number = versionCodeAndNumber2[1];
                        if (info.versionCode < versionCode) {
                            TextView view = findViewById(R.id.apps_item_label);
                            view.setText(getString(R.string.updates_available_title));
                            TextView view2 = findViewById(R.id.apps_item_name);
                            view2.setText(getString(R.string.updates_available_desc));
                            final AppDetail detail = new AppDetail();
                            detail.label = info.applicationInfo.loadLabel(pm);
                            detail.name = info.packageName;
                            detail.icon = info.applicationInfo.loadIcon(pm);
                            detail.old_version_code = info.versionCode;
                            detail.new_version_code = versionCode;
                            detail.old_version_number = info.versionName;
                            detail.new_version_number = new_version_number;
                            detail.checked = false;
                            apps.add(detail);
                        } else {
                            upToDateApps++;
                            if (upToDateApps == 2) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        TextView view = findViewById(R.id.apps_item_label);
                                        view.setText(getString(R.string.no_updates_title));
                                        TextView view2 = findViewById(R.id.apps_item_name);
                                        view2.setText(getString(R.string.no_updates_desc));
                                    }
                                });
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            } else if (info.packageName.equals("com.magiclogics.softwareupdate")) {
                final DatabaseReference reference = database.getReference("softwareUpdateVersionCode");
                reference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String versionCodeAndNumber = String.valueOf(dataSnapshot.getValue());
                        String[] versionCodeAndNumber2 = versionCodeAndNumber.split(":");
                        long versionCode = Long.parseLong(versionCodeAndNumber2[0]);
                        String new_version_number = versionCodeAndNumber2[1];
                        if (info.versionCode < versionCode) {
                            TextView view = findViewById(R.id.apps_item_label);
                            view.setText(getString(R.string.updates_available_title));
                            TextView view2 = findViewById(R.id.apps_item_name);
                            view2.setText(getString(R.string.updates_available_desc));
                            final AppDetail detail = new AppDetail();
                            detail.label = info.applicationInfo.loadLabel(pm);
                            detail.name = info.packageName;
                            detail.icon = info.applicationInfo.loadIcon(pm);
                            detail.old_version_code = info.versionCode;
                            detail.new_version_code = versionCode;
                            detail.old_version_number = info.versionName;
                            detail.new_version_number = new_version_number;
                            detail.checked = false;
                            apps.add(detail);
                        } else {
                            upToDateApps++;
                            if (upToDateApps == 2) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        TextView view = findViewById(R.id.apps_item_label);
                                        view.setText(getString(R.string.no_updates_title));
                                        TextView view2 = findViewById(R.id.apps_item_name);
                                        view2.setText(getString(R.string.no_updates_desc));
                                    }
                                });
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        }
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ArrayAdapter<AppDetail> arrayAdapter = new ArrayAdapter<AppDetail>(MainActivity.this, R.layout.apps_layout, apps) {
                    @Override
                    public View getView(final int position, View convertView, ViewGroup parent) {
                        if (convertView == null) {
                            convertView = getLayoutInflater().inflate(R.layout.apps_layout, parent, false);
                        }

                        TextView label = convertView.findViewById(R.id.apps_item_label_adapter);
                        label.setText(apps.get(position).label);

                        TextView old_version = convertView.findViewById(R.id.apps_item_name_adapter);
                        old_version.setText(getString(R.string.version_old_new,
                                apps.get(position).old_version_number,
                                apps.get(position).new_version_number));

                        ImageView view = convertView.findViewById(R.id.apps_item_icon_adapter);
                        view.setImageDrawable(apps.get(position).icon);

                        final CheckBox checkBox = convertView.findViewById(R.id.checkbox_adapter);
                        if (apps.get(position).checked) {
                            checkBox.setChecked(true);
                        }
                        checkBox.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                apps.get(position).checked = checkBox.isChecked();
                            }
                        });

                        return convertView;
                    }
                };
                ListView view = findViewById(R.id.updates_list);
                view.setAdapter(arrayAdapter);
            }
        });
    }

    public void updateSoftware(View view) {
        @SuppressLint("StaticFieldLeak")
        AsyncTask<Void, Void, Void> task2 = new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                for (final AppDetail app : apps) {
                    if (app.checked) {
                        if (app.name.equals("com.magiclogics.magictube")) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(MainActivity.this, "!!!!", Toast.LENGTH_SHORT).show();
                                }
                            });
                            final FirebaseDatabase database = FirebaseDatabase.getInstance("https://magiclogicssoftwareupdat-b9f8e-default-rtdb.firebaseio.com/");
                            final DatabaseReference reference = database.getReference("magicTubeDownloadLink");
                            reference.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    final ProgressDialog downloading = new ProgressDialog(MainActivity.this);
                                    downloading.setMessage(getString(R.string.updates_downloading, app.label));
                                    downloading.setIndeterminate(true);
                                    downloading.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                                    downloading.show();

                                    DownloadManager.Request request = new
                                            DownloadManager.Request(Uri.parse(String.valueOf(dataSnapshot.getValue())));
                                    request.setTitle(app.label);
                                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                                    request.setDestinationInExternalFilesDir(MainActivity.this, null,
                                            app.name + ".apk");

                                    DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                                    manager.enqueue(request);

                                    if (!receiverRegistered) {
                                        BroadcastReceiver receiver = new BroadcastReceiver() {
                                            @Override
                                            public void onReceive(Context context, Intent intent) {
                                                downloading.dismiss();
                                                Intent intent2 = new Intent(Intent.ACTION_INSTALL_PACKAGE);
                                                intent2.setData(FileProvider.getUriForFile(context, context.getApplicationContext().getPackageName() + ".provider",
                                                        new File(getExternalFilesDir(null) + "/" + app.name + ".apk")));
                                                intent2.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                                startActivityForResult(intent2, MAGICTUBE_REQUEST_CODE);
                                            }
                                        };

                                        registerReceiver(receiver, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
                                        receiverRegistered = true;
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                        } else if (app.name.equals("com.magiclogics.softwareupdate")) {
                            final FirebaseDatabase database = FirebaseDatabase.getInstance("https://magiclogicssoftwareupdat-b9f8e-default-rtdb.firebaseio.com/");
                            final DatabaseReference reference = database.getReference("softwareUpdateDownloadLink");
                            reference.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    DownloadManager.Request request = new
                                            DownloadManager.Request(Uri.parse(String.valueOf(dataSnapshot.getValue())));
                                    request.setTitle(app.label);
                                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                                    request.setDestinationInExternalFilesDir(MainActivity.this, null,
                                            app.name + ".apk");

                                    DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                                    manager.enqueue(request);

                                    if (!receiverRegistered) {
                                        BroadcastReceiver receiver = new BroadcastReceiver() {
                                            @Override
                                            public void onReceive(Context context, Intent intent) {
                                                Intent intent2 = new Intent(Intent.ACTION_INSTALL_PACKAGE);
                                                intent2.setData(FileProvider.getUriForFile(context, context.getApplicationContext().getPackageName() + ".provider",
                                                        new File(getExternalFilesDir(null) + "/" + app.name + ".apk")));
                                                intent2.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                                startActivityForResult(intent2, SOFTWAREUPDATE_REQUEST_CODE);
                                            }
                                        };

                                        registerReceiver(receiver, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
                                        receiverRegistered = true;
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                        }
                    }
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
            }
        };

        int i = 0;
        int checked = 0;
        while (i < apps.size()) {
            if (apps.get(i).checked) {
                checked++;
            }
            i++;
        }
        if (checked == 0) {
            Toast.makeText(this, getString(R.string.no_apps_checked), Toast.LENGTH_SHORT).show();
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (!getPackageManager().canRequestPackageInstalls()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setMessage(getString(R.string.request_inst_pkgs_msg));
                    builder.setPositiveButton(getString(R.string.accept), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES);
                            intent.setData(Uri.parse("package:" + getPackageName()));
                            //noinspection deprecation
                            startActivityForResult(intent, UNKNOWN_SOURCE_REQUEST_CODE);
                        }
                    });
                    builder.setNegativeButton(getString(R.string.decline), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    builder.show();
                } else {
                    task2.execute();
                }
            } else {
                task2.execute();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.updates_check_item:
                @SuppressLint("StaticFieldLeak")
                AsyncTask<Void, Void, Void> task = new AsyncTask<Void, Void, Void>() {
                    @Override
                    protected Void doInBackground(Void... voids) {
                        for (int i = 0; i < apps.size(); i++) {
                            apps.remove(i);
                        }
                        checkForUpdates();
                        return null;
                    }

                    @Override
                    protected void onPostExecute(Void aVoid) {
                        super.onPostExecute(aVoid);
                    }
                };
                task.execute();
                return true;
            case R.id.settings_item:
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                return true;
        }
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == MAGICTUBE_REQUEST_CODE) {
            if (resultCode == RESULT_OK || resultCode == RESULT_CANCELED) {
                new File(getExternalFilesDir(null) + "/com.magiclogics.magictube.apk").delete();
            }
        } else if (requestCode == SOFTWAREUPDATE_REQUEST_CODE) {
            if (resultCode == RESULT_OK || resultCode == RESULT_CANCELED) {
                new File(getExternalFilesDir(null) + "/com.magiclogics.softwareupdate.apk").delete();
            }
        } else if (requestCode == UNKNOWN_SOURCE_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                updateSoftware(null);
            }
        }
    }
}
