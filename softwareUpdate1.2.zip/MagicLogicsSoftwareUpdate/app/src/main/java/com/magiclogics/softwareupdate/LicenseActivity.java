package com.magiclogics.softwareupdate;

import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.InputStream;

public class LicenseActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_license);

        String license = "";
        try {
            InputStream stream = getAssets().open("COPYING");

            int size = stream.available();
            byte[] buffer = new byte[size];
            stream.read(buffer);
            stream.close();
            license = new String(buffer);
        } catch (Exception e) {

        }

        TextView view = findViewById(R.id.license_text);
        view.setText(license);
    }
}
