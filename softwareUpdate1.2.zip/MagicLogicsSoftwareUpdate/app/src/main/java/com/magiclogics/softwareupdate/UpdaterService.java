/*

Copyright (C) 2021 MagicLogics LLC.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.

*/

package com.magiclogics.softwareupdate;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.os.Build;
import android.os.IBinder;
import android.preference.PreferenceManager;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class UpdaterService extends Service {
    static boolean onBoot = false;
    static Context context;
    static boolean isRunning = false;
    boolean notificationSent = false;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        isRunning = true;
        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                final FirebaseDatabase database = FirebaseDatabase.getInstance("https://magiclogicssoftwareupdat-b9f8e-default-rtdb.firebaseio.com/");

                final PackageManager pm = getPackageManager();
                List<PackageInfo> list = pm.getInstalledPackages(0);
                for (final PackageInfo info : list) {
                    if (info.packageName.equals("com.magiclogics.magictube")) {
                        final DatabaseReference reference = database.getReference("magicTubeVersionCode");
                        reference.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                String versionCodeAndNumber = String.valueOf(dataSnapshot.getValue());
                                String[] versionCodeAndNumber2 = versionCodeAndNumber.split(":");
                                long versionCode = Long.parseLong(versionCodeAndNumber2[0]);
                                if (info.versionCode < versionCode) {
                                    if (!notificationSent) {
                                        Intent updatesIntent = new Intent(context, MainActivity.class);
                                        updatesIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, updatesIntent, 0);

                                        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, "0")
                                                .setSmallIcon(R.mipmap.ic_launcher)
                                                .setContentTitle(getString(R.string.notify_title))
                                                .setContentText(getString(R.string.notify_desc))
                                                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                                                .setContentIntent(pendingIntent)
                                                .setAutoCancel(true);
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                            CharSequence name = getString(R.string.updates_check);
                                            String description = getString(R.string.notify_channel_desc);
                                            int importance = NotificationManager.IMPORTANCE_DEFAULT;
                                            NotificationChannel channel = new NotificationChannel("0", name, importance);
                                            channel.setDescription(description);
                                            // Register the channel with the system; you can't change the importance
                                            // or other notification behaviors after this
                                            NotificationManager notificationManager = getSystemService(NotificationManager.class);
                                            notificationManager.createNotificationChannel(channel);
                                        }

                                        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);
                                        notificationManager.notify(0, builder.build());
                                        notificationSent = true;
                                        try {
                                            Thread.sleep(5000);
                                            notificationSent = false;
                                        } catch (InterruptedException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    } else if (info.packageName.equals("com.magiclogics.softwareupdate")) {
                        final DatabaseReference reference = database.getReference("softwareUpdateVersionCode");
                        reference.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                String versionCodeAndNumber = String.valueOf(dataSnapshot.getValue());
                                String[] versionCodeAndNumber2 = versionCodeAndNumber.split(":");
                                long versionCode = Long.parseLong(versionCodeAndNumber2[0]);
                                if (info.versionCode < versionCode) {
                                    if (!notificationSent) {
                                        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, "0")
                                                .setSmallIcon(R.mipmap.ic_launcher)
                                                .setContentTitle(getString(R.string.notify_title))
                                                .setContentText(getString(R.string.notify_desc))
                                                .setPriority(NotificationCompat.PRIORITY_DEFAULT);
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                            CharSequence name = getString(R.string.updates_check);
                                            String description = getString(R.string.notify_channel_desc);
                                            int importance = NotificationManager.IMPORTANCE_DEFAULT;
                                            NotificationChannel channel = new NotificationChannel("0", name, importance);
                                            channel.setDescription(description);
                                            // Register the channel with the system; you can't change the importance
                                            // or other notification behaviors after this
                                            NotificationManager notificationManager = getSystemService(NotificationManager.class);
                                            notificationManager.createNotificationChannel(channel);
                                        }

                                        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);
                                        notificationManager.notify(0, builder.build());
                                        notificationSent = true;
                                        try {
                                            Thread.sleep(5000);
                                            notificationSent = false;
                                        } catch (InterruptedException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }
                }
            }
        };

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        // 86400 = 1 day
        ConnectivityManager manager = (ConnectivityManager) context.getSystemService(CONNECTIVITY_SERVICE);
        if (!manager.isActiveNetworkMetered()) {
            if (prefs.getBoolean("checkForUpdates", true)) {
                if (onBoot) {
                    timer.schedule(task, 6000, 86400000);
                } else {
                    timer.schedule(task, 86400000, 86400000);
                }
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        isRunning = false;
    }
}
