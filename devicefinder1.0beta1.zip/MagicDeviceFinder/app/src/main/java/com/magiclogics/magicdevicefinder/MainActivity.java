/*

Copyright (C) 2021 MagicLogics LLC.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.

*/

package com.magiclogics.magicdevicefinder;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@SuppressWarnings("Convert2Lambda")
public class MainActivity extends AppCompatActivity {
    FirebaseAuth auth;
    FirebaseUser currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        auth = FirebaseAuth.getInstance();
        currentUser = auth.getCurrentUser();
        if (currentUser != null) {
            initDeviceFinding();
        } else {
            setContentView(R.layout.activity_main);
        }
    }

    public void logIn(View view) {
        EditText email = findViewById(R.id.email);
        EditText password = findViewById(R.id.password);
        auth.signInWithEmailAndPassword(email.getText().toString(),
                password.getText().toString())
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            setContentView(R.layout.activity_device_find);
                        } else {
                            Toast.makeText(MainActivity.this, R.string.cred_incorrect, Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    public void register(View view) {
        final EditText email = findViewById(R.id.email);
        final EditText password = findViewById(R.id.password);
        EditText confirm_password = findViewById(R.id.confirm_password);
        RadioButton client = findViewById(R.id.client);
        RadioButton server = findViewById(R.id.server);
        if (!confirm_password.getText().toString().equals(password.getText().toString())) {
            Toast.makeText(this, getString(R.string.confirmed_password_incorrect), Toast.LENGTH_SHORT).show();
        } else {
            // encrypt email
            String email2 = "";

            FirebaseDatabase instance = FirebaseDatabase.getInstance();
            DatabaseReference reference = instance.getReference();
            String key = reference.push().getKey();
            DatabaseReference user = reference.child(key);

            EditText text = findViewById(R.id.email_server);
            if (client.isChecked()) {
                email2 = text.getText().toString();
            }

            Encryption encryption = Encryption.getDefault(email.getText().toString(), "Salt", new byte[16]);
            String enc_email = encryption.encryptOrNull(email.getText().toString());
            String enc_watcher = email2;

            /*Map<String, String> hashMap = new HashMap<>();
            hashMap.put("email2", enc_email);
            if (text.getText().toString().equals("")) {
                hashMap.put("watcherEmail", "");
            } else {
                hashMap.put("watcherEmail", enc_watcher);
            }
            hashMap.put("locationName", "");*/
            AccountDetails details = new AccountDetails();
            details.email2 = enc_email;
            details.locationName = "";
            details.watcherEmail = enc_watcher;
            details.timestamp = Calendar.getInstance().getTime().getTime();
            String json = new Gson().toJson(details);

            Map<String, String> hashMap = new HashMap<>();
            hashMap.put("json", json);

            user.setValue(hashMap);

            auth.createUserWithEmailAndPassword(email.getText().toString(), password.getText().toString())
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(MainActivity.this, getString(R.string.register_success), Toast.LENGTH_SHORT).show();
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                    setContentView(R.layout.activity_permissions);
                                } else {
                                    initDeviceFinding();
                                }
                            }
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            if (e.toString().contains("Password should be at least 6 characters")) {
                                Toast.makeText(MainActivity.this, getString(R.string.password_too_short), Toast.LENGTH_SHORT).show();
                                user.removeValue();
                                user.getParent().removeValue();
                            }
                        }
                    });
        }
    }

    public void createAccount(View view) {
        setContentView(R.layout.activity_create_account);
    }

    public void onClientClick(View view) {
        RadioButton client = findViewById(R.id.client);
        RadioButton server = findViewById(R.id.server);
        client.setChecked(true);
        server.setChecked(false);
        EditText text = findViewById(R.id.email_server);
        text.setVisibility(View.VISIBLE);
    }

    public void onServerClick(View view) {
        RadioButton client = findViewById(R.id.client);
        RadioButton server = findViewById(R.id.server);
        client.setChecked(false);
        server.setChecked(true);
        EditText text = findViewById(R.id.email_server);
        text.setVisibility(View.GONE);
    }

    public void onGrantClick(View view) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_BACKGROUND_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACCESS_FINE_LOCATION}, 9999);
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACCESS_FINE_LOCATION}, 9998);
        }
    }

    public void onDenyClick(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.permissions_required_dialog_title));
        builder.setMessage(getString(R.string.permissions_required_dialog_desc));
        builder.setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                onGrantClick(null);
            }
        });
        builder.setNegativeButton(getString(R.string.exit_app), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
                android.os.Process.killProcess(android.os.Process.myPid());
            }
        });
        builder.show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 9999) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED
            && grantResults[2] == PackageManager.PERMISSION_GRANTED) {
                initDeviceFinding();
            } else {
                onDenyClick(null);
            }
        } else if (requestCode == 9998) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                initDeviceFinding();
            } else {
                onDenyClick(null);
            }
        }
    }

    boolean isServerAccount;

    @SuppressLint("MissingPermission") // Permission is granted before initializing the UI and the app won't run without it.
    private void initDeviceFinding() {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference root = database.getReference();

        // Are we the server or the client?
        root.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                    System.out.println(snapshot1.getValue());
                    Type type = new TypeToken<AccountDetails>() {}.getType();
                    AccountDetails details = new Gson().fromJson(snapshot1.getValue().toString(), type);
                    String email;
                    String email_watcher;
                    try {
                        Encryption encryption = Encryption.getDefault(auth.getCurrentUser().getEmail(), "Salt", new byte[16]);
                        System.out.println("Encrypted: " + details.email2);
                        email = encryption.decrypt(details.email2);
                        email_watcher = details.watcherEmail;
                    } catch (Exception e) {
                        e.printStackTrace();
                        continue;
                    }
                    if (auth.getCurrentUser().getEmail().equals(email)) {
                        if (email_watcher.equals("")) {
                            isServerAccount = true;
                        } else {
                            isServerAccount = false;
                        }
                    }
                    /*if (snapshot1.getKey().equals("email")) {
                        try {
                            Encryption encryption = Encryption.getDefault(auth.getCurrentUser().getEmail(), "Salt", new byte[16]);
                            String email = encryption.decrypt((String) snapshot1.getValue());
                            if (email.equals(auth.getCurrentUser().getEmail())) {
                                continue;
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    if (snapshot1.getKey().equals("watcherEmail")) {
                        if (snapshot1.getValue().equals("")) {
                            isServerAccount = true;
                        } else {
                            isServerAccount = false;
                        }
                    }*/
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        String key = root.push().getKey();

        setContentView(R.layout.activity_loading);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (isServerAccount) {
                    startService(new Intent(MainActivity.this, LocationService.class));
                    // There is no way to get all children by default
                    // but there is a workaround:
                    // 1. Add a child event listener that watches for child event changes.
                    // 2. Add a child.
                    // 3. The listener gets called and we can get all of the entries.
                    LocationManager locationManager = (LocationManager)
                            getSystemService(Context.LOCATION_SERVICE);
                    LocationListener listener = new LocationListener() {
                        @Override
                        public void onLocationChanged(Location location) {
                            root.addChildEventListener(new ChildEventListener() {

                                @Override
                                public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                                    for (DataSnapshot child : snapshot.getChildren()) {

                                    }

                                    String cityName = null;
                                    Geocoder gcd = new Geocoder(getBaseContext(), Locale.getDefault());
                                    List<Address> addresses;
                                    try {
                                        addresses = gcd.getFromLocation(location.getLatitude(),
                                                location.getLongitude(), 1);
                                        if (addresses.size() > 0) {
                                            System.out.println(addresses.get(0).getLocality());
                                            cityName = addresses.get(0).getLocality();
                                        }
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }

                                    System.out.println(snapshot.getValue());

                                    TextView view = findViewById(R.id.current_loc);
                                    view.setText(getString(R.string.current_loc, cityName));

                                    // Save new location to account details
                                    for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                                        Type type = new TypeToken<AccountDetails>() {}.getType();
                                        AccountDetails details = new Gson().fromJson(snapshot1.getValue().toString(), type);

                                        System.out.println(auth.getCurrentUser().getEmail() + "=" + auth.getCurrentUser().getEmail().getBytes().length);

                                        Encryption encryption = Encryption.getDefault(auth.getCurrentUser().getEmail(), "Salt", new byte[16]);
                                        try {
                                            encryption.decrypt(details.email2);
                                        } catch (Exception e) {
                                            continue;
                                        }

                                        details.locationName = encryption.encryptOrNull(cityName);
                                        details.timestamp = Calendar.getInstance().getTime().getTime();

                                        String json = new Gson().toJson(details);
                                        System.out.println(snapshot1.getKey());
                                        DatabaseReference ref = snapshot1.getRef();
                                        ref.setValue(json);
                                    }
                                }

                                @Override
                                public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                                }

                                @Override
                                public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                                }

                                @Override
                                public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });
                            String key = root.push().getKey();
                        }

                        @Override
                        public void onStatusChanged(String provider, int status, Bundle extras) {

                        }

                        @Override
                        public void onProviderEnabled(String provider) {

                        }

                        @Override
                        public void onProviderDisabled(String provider) {

                        }
                    };
                    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 10, listener);

                    setContentView(R.layout.activity_device_find);
                } else {
                    root.addChildEventListener(new ChildEventListener() {
                        @Override
                        public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                            System.out.println("It works!!!!!!!");
                            for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                                Type type = new TypeToken<AccountDetails>() {
                                }.getType();
                                System.out.println(snapshot1.getValue().toString());
                                AccountDetails details = new Gson().fromJson(snapshot1.getValue().toString(), type);
                                /*System.out.println(details.watcherEmail);
                                System.out.println(details.watcherEmail + "=" + details.watcherEmail.getBytes().length);
                                Encryption enc = Encryption.getDefault(details.watcherEmail, "Salt", new byte[16]);
                                String orig_email;
                                try {
                                    orig_email = enc.decrypt(details.email2);
                                } catch (Exception e) {
                                    System.out.println("Error: " + e.toString());
                                    continue;
                                }
                                if (orig_email.equals(details.watcherEmail)) {
                                    Encryption encryption = Encryption.getDefault(details.watcherEmail, "Salt", new byte[16]);
                                    String enc_location = null;
                                    try {
                                        enc_location = encryption.decrypt(details.locationName);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        continue;
                                    }
                                    TextView loc = findViewById(R.id.current_loc);
                                    loc.setText(getString(R.string.current_loc_server, enc_location));
                                }*/
                                Encryption enc = Encryption.getDefault(auth.getCurrentUser().getEmail(), "Salt", new byte[16]);
                                String email = "";
                                try {
                                    email = enc.decrypt(details.email2);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                if (email.equals(auth.getCurrentUser().getEmail())) {
                                    System.out.println("We found or email!");
                                    // Find our watcher email account!
                                    ChildEventListener listener = new ChildEventListener() {
                                        @Override
                                        public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                                            for (DataSnapshot snapshot2 : snapshot.getChildren()) {
                                                AccountDetails details2 = new Gson().fromJson(snapshot2.getValue().toString(), type);
                                                System.out.println("JSON: " + snapshot2.getValue().toString());
                                                Encryption enc = Encryption.getDefault(details.watcherEmail, "Salt", new byte[16]);
                                                String watcher_mail;
                                                try {
                                                    watcher_mail = enc.decrypt(details2.email2);
                                                } catch (Exception e) {
                                                    e.printStackTrace();
                                                    continue;
                                                }
                                                System.out.println("Watcher email: " + watcher_mail);
                                                if (details.watcherEmail.equals(watcher_mail)) {
                                                    // Get our location!
                                                    String cur_loc = "";
                                                    try {
                                                        cur_loc = enc.decrypt(details2.locationName);
                                                    } catch (Exception e) {
                                                        e.printStackTrace();
                                                        continue;
                                                    }

                                                    // If the timestamp is longer than 5 minutes long, then assume
                                                    // the server is offline
                                                    long timestamp_server = details2.timestamp;
                                                    long timestamp_current = Calendar.getInstance().getTime().getTime();
                                                    if ((timestamp_current - timestamp_server) >= (300 * 1000)) {
                                                        TextView view = findViewById(R.id.current_loc);
                                                        view.setText(getString(R.string.current_loc_server, getString(R.string.offline)));
                                                    } else {

                                                        TextView view = findViewById(R.id.current_loc);
                                                        view.setText(getString(R.string.current_loc_server, cur_loc));
                                                    }
                                                }
                                            }
                                        }

                                        @Override
                                        public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                                        }

                                        @Override
                                        public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                                        }

                                        @Override
                                        public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {

                                        }
                                    };
                                    root.addChildEventListener(listener);
                                    String key = root.push().getKey();
                                    FirebaseDatabase instance = FirebaseDatabase.getInstance();
                                    DatabaseReference ref = instance.getReference(key);
                                    ref.setValue("blabla");
                                    ref.removeValue();
                                }
                            }
                        }

                        @Override
                        public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                        }

                        @Override
                        public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                        }

                        @Override
                        public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                    String key = root.push().getKey();
                    FirebaseDatabase instance = FirebaseDatabase.getInstance();
                    DatabaseReference ref = instance.getReference(key);
                    ref.setValue("blabla");
                    ref.removeValue();

                    setContentView(R.layout.activity_device_find_client);
                }
            }
        }, 2000);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_refresh:
                initDeviceFinding();
                return true;
        }
        return true;
    }
}
